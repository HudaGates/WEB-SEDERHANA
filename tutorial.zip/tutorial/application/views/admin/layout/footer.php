<div class="clearfix"></div>
    <footer>Web Design by Ahmad M Huda - &copy; by Ahmad M Huda </footer>    
</div>
</body>
</html>